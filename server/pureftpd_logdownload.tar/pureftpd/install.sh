#!/bin/sh

# Add ftp system group and user
# uid 2121 is allowed download ant upload,
# uid 2122 is allowed only download.

groupadd -g 2121 ftpgroup
useradd -g 2121 -u 2121 -s /sbin/nologin -d /dev/null ftpuser
useradd -g 2121 -u 2122 -s /sbin/nologin -d /dev/null ftpdown

# start with system

echo "" >> /etc/rc.local
echo "FTP Server Start:" >> /etc/rc.local
echo "/usr/local/pureftpd/sbin/pure-ftpd -A -B -c300 -C5 -D -E -fftp -H -I15 -lpuredb:/usr/local/pureftpd/etc/pureftpd.pdb -L8000:8 -m4 -s -U133:022 -u100 -j -k99 -Z -O clf:/var/log/pureftpd.log" >> /etc/rc.local

# add root directory:
mkdir /var/ftproot
