#!/bin/sh

# pure ftpd start:
# by Felix N.

# if old pureftpd is running, kill it first:
if [ -f /var/run/pure-ftpd.pid ]
then
	echo "Warning: pureftpd is running now, kill it first"
	echo "         Hit any key to kill the running and start the new one, Ctrl+c to interrupt"
	read rst
	kill `cat /var/run/pure-ftpd.pid`
	if [ $? = 0 ]; then
		echo "Note: pureftpd is killed successed" 
	else
		echo "Error: kill running pureftpd error!!!"
		echo "       Please kill it manual first, then start the new one"
		exit 1
	fi
fi

# start the new one

#FTP Server Start:
/usr/local/pureftpd/sbin/pure-ftpd -S 55621 -A -B -c300 -C5 -D -E -fftp -H -I15 -lpuredb:/usr/local/pureftpd/etc/pureftpd.pdb -L30000:8 -m4 -s -U133:022 -u100 -j -k99 -Z -O clf:/var/log/pureftpd.log

if [ $? = 0 ];then
	echo "Note: pureftpd started!"
else
	echo "Error: I can NOT start pureftpd, check it, i don't know why"
fi
